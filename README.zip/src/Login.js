import "./index.css";

import Header from './components/header'
import Section from "./components/section";
import Section2 from "./components/section2";
import Section3 from "./components/section3";
import Section4 from "./components/section4";
import Footer from "./components/footer";

const Login = () => {
    return (
    <div className="App">
   <h1>Teste</h1>

    </div>
  );
}
 
export default Login;


