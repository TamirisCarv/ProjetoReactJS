import tags from '../components/tags.png';
import play from '../components/google-play.png';
export default function Section4(){
    return (

    
        <section className="section4">
          
          <div class="beneficios.conte">
        <div className="delivery">Peça pelo Delivery</div>
        <button className="textode">Pedir</button>
    </div>

    <div class="imagem-container">
        <img className="app" src={tags} alt="app" />
       
    </div>
         
        

        
       
   </section>
    )
} 