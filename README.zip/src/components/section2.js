export default function Section2(){
    return (

    
        <section className="section2">
          
   
   
          <button className="catalogo">Acessar cardápio!</button>
        

        
       
   </section>
    )
} 