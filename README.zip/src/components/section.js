import bannerImage from '../components/banner.png';

export default function Section(){
    return (

    
        <section className="section">
          
   
   
   <div className="slogansub">Experimente o doce sabor da felicidade</div>
           {/* <article>
           <div className="slogan">
        Amor à primeira
        <span className="vista">   <span className="riscado">vista</span></span> <br />
        <span className="destacado">mordida</span>
      </div>
     

        <div class="circuloBlur"></div>
        </article> */}

        
       
   </section>
    )
} 