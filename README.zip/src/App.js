import AppRoutes from "./Routes";
 
// import Header from "./components/Header";
// import Banner from "./components/Banner";
// import Lanches from "./components/Lanches";
// import Sobremesas from "./components/Sobremesas";
// import Delivery from "./components/Delivery";
// import Footer from "./components/Footer";
// import RoutesApp from "./routes";
// // import Section from "./components/Section";
// // import ListItem from "./components/ListItem";
 
function App() {
  return (
    <div className="App">
      <AppRoutes/>
    </div>
  );
}
 
export default App;